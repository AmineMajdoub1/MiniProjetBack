package com.example.Articles;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.Articles.entites.Article;
import com.example.Articles.entites.Journal;
import com.example.Articles.repos.ArticleRepository;

@SpringBootTest
class ArticlesJournalApplicationTests {

	@Autowired
	private ArticleRepository articleRepository;
	@Test
	public void testCreateArticle() {
	Article art = new Article("Math","Recherche",new Date());
	articleRepository.save(art);
	}
	@Test
	public void testFindArticle()
	{
	Article art = articleRepository.findById(1L).get(); 
	System.out.println(art);
	}
	@Test
	public void testUpdateArticle()
	{
	Article art = articleRepository.findById(1L).get();
	art.setTypeArticle("Recherche");
	articleRepository.save(art);
	}
	
	@Test
	public void testDeleteArticle()
	{
	articleRepository.deleteById(4L);;
	}
	
	@Test
	public void testListerTousArticles()
	{
	List<Article> arts = articleRepository.findAll();
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	
	@Test
	public void testFindByTitreArticle()
	{
	List<Article> arts = articleRepository.findByTitreArticle("Nuclar"); 
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	@Test
	public void findByTitreArticleContains()
	{
	List<Article> arts = articleRepository.findByTitreArticleContains("Nu"); 
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	@Test
	public void testfindByTitreType()
	{
	List<Article> arts = articleRepository.findByTitreType("Nuclar", "Recherche");
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	@Test
	public void testfindByCategorie()
	{
	Journal jour = new Journal();
	jour.setIdJour(1L);
	List<Article> arts = articleRepository.findByJournal(jour);
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	@Test
	public void testfindByJournalIdJour()
	{
	List<Article> arts = articleRepository.findByJournalIdJour(1L);
	for (Article art : arts)
	{
	System.out.println(art);
	}
	 }
	@Test
	public void testfindByOrderByTitreArticleAsc()
	{
	List<Article> arts = articleRepository.findByOrderByTitreArticleAsc();
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}
	@Test
	public void testtrierArticlesTitreType()
	{
	List<Article> arts = articleRepository.trierArticlesTitreType();
	for (Article art : arts)
	{
	System.out.println(art);
	}
	}


	



}
