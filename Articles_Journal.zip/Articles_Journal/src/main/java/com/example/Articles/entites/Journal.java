package com.example.Articles.entites;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Journal {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    
	private Long idJour;
	private String nomJour;
	private String descJour;
	private Double  prixJour ;
	@OneToMany (mappedBy = "journal")
	@JsonIgnore
	private List<Article> articles;
	
	
	
	public Journal() {
		super();
	}
	public Long getIdJour() {
		return idJour;
	}
	public void setIdJour(Long idJour) {
		this.idJour = idJour;
	}
	public String getNomJour() {
		return nomJour;
	}
	public void setNomJour(String nomJour) {
		this.nomJour = nomJour;
	}
	public String getDescJour() {
		return descJour;
	}
	public void setDescJour(String descJour) {
		this.descJour = descJour;
	}
	public Double getPrixJour() {
		return prixJour;
	}
	public void setPrixJour(Double prixJour) {
		this.prixJour = prixJour;
	}
	public List<Article> getArticles() {
		return articles;
	}
	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}


	

}
