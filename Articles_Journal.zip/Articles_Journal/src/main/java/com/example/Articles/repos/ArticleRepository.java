package com.example.Articles.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.example.Articles.entites.Article;
import com.example.Articles.entites.Journal;
@RepositoryRestResource(path = "rest")
public interface ArticleRepository extends JpaRepository<Article, Long> {
	List<Article> findByTitreArticle(String titre);
	 List<Article> findByTitreArticleContains(String titre);
	 /*@Query("select a from Article a where a.titreArticle like %?1 and a.typeArticle like %?2")
	 List<Article> findByTitreType (String titre, String type);*/
	 @Query("select a from Article a where a.titreArticle like %:titre and a.typeArticle like %:type")
	 List<Article> findByTitreType (@Param("titre") String titre,@Param("type") String type);

	 
	 @Query("select a from Article a where a.journal = ?1")
	 List<Article> findByJournal (Journal journal);
	 List<Article> findByJournalIdJour (Long id);
	 List<Article> findByOrderByTitreArticleAsc();
	 
	 @Query("select a from Article a order by a.titreArticle ASC, a.typeArticle DESC")
	 List<Article> trierArticlesTitreType ();

}
