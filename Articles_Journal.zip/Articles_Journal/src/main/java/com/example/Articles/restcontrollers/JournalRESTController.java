package com.example.Articles.restcontrollers;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.example.Articles.entites.Article;
import com.example.Articles.entites.Journal;
import com.example.Articles.repos.JournalRepository;
@RestController
@RequestMapping("/api/Journal")
@CrossOrigin
public class JournalRESTController {
	@Autowired
	JournalRepository journal;
	@RequestMapping(method=RequestMethod.GET)
	public List<Journal> getAllArticles()
	{
	   return journal.findAll();
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
    public Journal getJournalById(@PathVariable("id") Long id) {
    return  journal.findById(id).get();
     }
	
	@RequestMapping(method = RequestMethod.PUT)
    public Journal updateJournal(@RequestBody Journal jour) {
    return journal.save(jour);
    }
	
	@RequestMapping(value="/{id}",method = RequestMethod.DELETE)
    public void deleteJournal(@PathVariable("id") Long id)
    {
    	journal.deleteById(id);
    }

	
	
	
	
	
	
	
	
	
	
}
