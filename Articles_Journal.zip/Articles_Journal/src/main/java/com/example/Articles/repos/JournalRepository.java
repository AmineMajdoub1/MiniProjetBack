package com.example.Articles.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Articles.entites.Article;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.example.Articles.entites.Journal;

public interface JournalRepository extends JpaRepository<Journal, Long>{
	
	
	

}
