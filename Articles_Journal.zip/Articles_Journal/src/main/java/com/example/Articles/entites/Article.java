package com.example.Articles.entites;

import java.util.Date;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
@Entity
public class Article {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long idArticle;
	private String titreArticle;
    private String typeArticle;
    private Date dateSortie;
    
    @ManyToOne
    private Journal journal;



public Article()
{
	super();
}

public Article(String titreArticle, String typeArticle, Date dateSortie) {
	super();
	this.titreArticle = titreArticle;
	this.typeArticle = typeArticle;
	this.dateSortie = dateSortie;
}

public Long getIdArticle() {
	return idArticle;
}

public void setIdArticle(Long idArticle) {
	this.idArticle = idArticle;
}

public String getTitreArticle() {
	return titreArticle;
}

public void setTitreArticle(String titreArticle) {
	this.titreArticle = titreArticle;
}

public String getTypeArticle() {
	return typeArticle;
}

public void setTypeArticle(String prixArticle) {
	typeArticle = prixArticle;
}

public Date getDateSortie() {
	return dateSortie;
}

public void setDateSortie(Date dateSortie) {
	this.dateSortie = dateSortie;
}

@Override
public String toString() {
	return "Article [idArticle=" + idArticle + ", titreArticle=" + titreArticle + ", typeArticle=" + typeArticle
			+ ", dateSortie=" + dateSortie + "]";
}

public Journal getJournal() {
	return journal;
}

public void setJournal(Journal journal) {
	this.journal = journal;
}
}
