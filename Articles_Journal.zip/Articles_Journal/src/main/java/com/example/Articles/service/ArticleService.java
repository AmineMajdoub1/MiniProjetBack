package com.example.Articles.service;

import java.util.List;

import com.example.Articles.entites.Article;
import com.example.Articles.entites.Journal;

public interface ArticleService {
	Article saveArticle(Article art);
	Article updateArticle(Article art);
	void deleteArticle(Article art);
	 void deleteArticleById(Long id);
	 Article getArticle(Long id);
	List<Article> getAllArticles();
	List<Article> findByTitreArticle(String titre);
	List<Article> findByTtireArticleContains(String titre);
	List<Article> findByTitreType (String titre, String type);
	List<Article> findByJournal (Journal journal);
	List<Article> findByJournalIdJour(Long id);
	List<Article> findByOrderByTitreJournalAsc();
	List<Article> trierArticlesTitreType();

}
