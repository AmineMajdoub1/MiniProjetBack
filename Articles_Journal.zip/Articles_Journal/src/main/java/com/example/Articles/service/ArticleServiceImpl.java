package com.example.Articles.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Articles.entites.Article;
import com.example.Articles.entites.Journal;
import com.example.Articles.repos.ArticleRepository;
@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired  // Add this annotation

    ArticleRepository articleRepository;

	@Override
	public Article saveArticle(Article art) {
       
		return articleRepository.save(art) ;
	}
	@Override
	public Article updateArticle(Article art) {

		return articleRepository.save(art) ;
	}

	@Override
	public void deleteArticle(Article art) {
		articleRepository.delete(art);
	}

	@Override
	public void deleteArticleById(Long id) {
		articleRepository.deleteById(id);

	}

	@Override
	public Article getArticle(Long id) {
		return articleRepository.findById(id).get();
	}

	@Override
	public List<Article> getAllArticles() {
		return articleRepository.findAll();
		}
	@Override
	public List<Article> findByTitreArticle(String titre) {
		// TODO Auto-generated method stub
		return articleRepository.findByTitreArticle(titre);
	}
	@Override
	public List<Article> findByTtireArticleContains(String titre) {
		// TODO Auto-generated method stub
		return articleRepository.findByTitreArticleContains(titre);
	}
	@Override
	public List<Article> findByTitreType(String titre, String type) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Article> findByJournal(Journal journal) {
		// TODO Auto-generated method stub
		return articleRepository.findByJournal(journal);
	}
	@Override
	public List<Article> findByJournalIdJour(Long id) {
		// TODO Auto-generated method stub
		return articleRepository.findByJournalIdJour(id);
	}
	@Override
	public List<Article> findByOrderByTitreJournalAsc() {
		// TODO Auto-generated method stub
		return articleRepository.findByOrderByTitreArticleAsc();
	}
	@Override
	public List<Article> trierArticlesTitreType() {
		// TODO Auto-generated method stub
		return articleRepository.trierArticlesTitreType();
	}

}
